# 📦 CHANGELOG

Todas as alterações notáveis do sistema Omni Keywords Finder serão documentadas aqui.

## [1.2.0] - 2025-03-24
### Adicionado
- Dashboard interativo no Prompt Manager
- Coletor para Medium e Pinterest
- Geração automática de prompts com placeholders

### Corrigido
- Validação duplicada no Google Planner
- Bug no endpoint /coletar (verificação de tema_id)

### Alterado
- Estrutura modular de API segmentada por nichos

---

## [1.1.0] - 2025-03-10
### Adicionado
- Validador de palavras por ML + Score

### Corrigido
- Falha ao exportar arquivos ZIP com nomes inválidos

---

## [1.0.0] - 2025-02-20
### Lançamento inicial
- Login, coleta básica, visualização de temas
